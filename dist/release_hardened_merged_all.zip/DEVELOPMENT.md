# Development Guide (Starter)
- `make manifests` to (re)generate CRDs
- `make run` to run locally (no image build)
- Webhook uses port 9443 and requires serving certs via cert-manager when deployed.
