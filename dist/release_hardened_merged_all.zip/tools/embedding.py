
"""Deterministic 2D embedding (placeholder).
Contract: lock sign/axes; round to 4dp; sort keys before emit.
"""
