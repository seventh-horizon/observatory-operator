
"""Compute Φ/κ and φ matrix (placeholder).
Deterministic: sorts inputs; emits floats with 4dp rounding.
"""
