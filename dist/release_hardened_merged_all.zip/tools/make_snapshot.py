
"""Write field/timeline/<TAG>.json (placeholder).
Ensure LC_ALL/TZ frozen; refuse dirty/untracked.
"""
