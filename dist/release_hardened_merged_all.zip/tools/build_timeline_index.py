
"""Build + sign field/timeline.index.json (placeholder).
Emit .asc alongside. Support --no-gpg for CI smoke.
"""
