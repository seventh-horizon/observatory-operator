
"""Validate timeline assets (placeholder).
Checks: chain_root, symmetry, semver monotonicity, 4-dp coords.
"""
