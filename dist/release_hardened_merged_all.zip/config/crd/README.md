CRDs are generated into this folder by `make manifests` using controller-gen.
Do not hand-edit generated YAMLs.
